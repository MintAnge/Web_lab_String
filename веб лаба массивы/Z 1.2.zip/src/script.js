const massiv = (array) => {
    let a2 = []
    for (i =0; i<array.length; i++ ) {
      a2[i] = array[array.length-i-1]
    }
  return a2  
}
let a = [9, 3, 5, 6] 
console.log(massiv(a))