const massiv = int => {
    let a = []
    for (i =0; i<10; i++ ) {
      a[i] = int 
    }
  console.log(a);  
}
console.log(massiv(9))