const massiv = (array) => {
  for (const value of array) {
    console.log(value)
  };
}
let a = [[1, 1], [2, 2], [3, 3]] 
massiv(a)