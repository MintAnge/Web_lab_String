const massiv = (array, ...args) => {
  let a = [...array];
  for (let i = 0; i < args.length; i++) {
    a = a.filter((b) => b !== args[i]);
  }
  return a;
}
let a = [9, 3, 5, 6] 
console.log(massiv(a, 9,3))