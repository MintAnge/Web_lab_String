const massiv = (array) => {
  return array.flat(Infinity);
}
let a = [1, 2, [3, 4, [5]]] 
console.log(massiv(a))