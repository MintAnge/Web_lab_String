let str = 'var\_test\_text'
let arr = str.split("_")
for (let i=1;i<arr.length;i++){
arr[i] = arr[1][0].toUpperCase()+arr[i].substring(1)
}
let result = arr.join('')
console.log(result)