let arr = ['I', 'learn', 'JavaScript' , '!']
let s1 =arr.join('+')
console.log(s1)