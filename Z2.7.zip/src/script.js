let s1 = 'I learn JavaScript!'
let arr1 = s1.split(' ')
let arr2 = s1.split('')
console.log(arr1)
console.log(arr2)

