let s1 = 'aaa bbb ccc'
console.log(s1.substr(4, 3));
console.log(s1.substring(4, 7));
console.log(s1.slice(4, 7)); 