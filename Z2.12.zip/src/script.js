const count = string => {
  let str = ''
if (string) {
      let regexReplacer = /a|e|i|o|u/g
      str = string.toLowerCase().replace(regexReplacer, '')}
      return string.length - str.length}
console.log(count('aabwertyWERTVBNMOLK<tyuqwer'))