let s1 = 'aaa@bbb@ccc'
console.log(s1.replace(/@/g, '!'))
document.querySelector('#header').innerHTML = s1.replace(/@/g, '!')