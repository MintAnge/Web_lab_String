let s1 = 'JS'
let s2 = 'js'
console.log('JS to lower case is: ' + s1.toLowerCase())
console.log('js to upper case is: ' + s2.toUpperCase())