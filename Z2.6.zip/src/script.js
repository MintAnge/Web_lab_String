let s1 = 'I−learn−JavaScript!'
console.log(s1.replace(/−/g, '!'))

