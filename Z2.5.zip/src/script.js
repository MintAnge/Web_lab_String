let s1 = 'I learn JavaScript!'
console.log('Длинна строки: '+s1.length)
console.log('Через substr: ' + s1.substr(2, 5) +' '+ s1.substr(8, 10))
console.log('Через substring: ' + s1.substring(2, 7) +' '+ s1.substring(8, 18)  ) 
console.log('Через slice: ' + s1.slice(2, 7) +' '+ s1.slice(8, 18))
console.log('Индекс слова learn: ' + s1.indexOf('learn'))
console.log('\nРезультат работы программы, которая обрезает строку до определенного индекса. \nИсходная строка: Съешь ещё этих мягких французских булок, да выпей же чаю \nРезультат после обрезания до 39 символа: ')
let str = 'Съешь ещё этих мягких французских булок, да выпей же чаю'
let n = 39
let result = ''
if (str.length>n) {
  result = str.substring(0, n)+'...'
}
else {
  result = str
}
console.log(result)
