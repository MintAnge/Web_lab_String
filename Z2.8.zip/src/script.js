let s1 = '2025−12−31'
let arr = s1.split('−')
let newS1 = arr[2] + '.' + arr[1] + '.'+arr[0]
console.log(newS1)

