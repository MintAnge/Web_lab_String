const isPalindrome = string => {
  let cleanString=''
if (string) {
      let regexReplacer = /\.|\,| |\!|\?|\'|\"|\/|\\|\-|\_|\+|\‘|\’/g
      cleanString = string.replace(regexReplacer, '').toLowerCase()
      }
 	  let str2 = cleanString.split('').reverse().join('')
    return cleanString == str2
}
let result = isPalindrome('papap')
console.log(result)